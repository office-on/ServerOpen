-----------------------------------------------------------
-- @@ScriptName: Game_Finger.lua
-- @@Author: popipo.yr<popipo@foxmail.com>
-- @@Create Date: 2014-06-20 14:59:05
-- @@Modify Date: 2015-04-15 15:25:23
-- @@Function:
-----------------------------------------------------------

require("app.UI.Menu.GameMenu")
require("app.Data.XSDataEngine.XSDataEngine")
require("app.Data.XSViewETC.XSViewETC")

require("app.UnitTool.EventPool")

require("Finger.FireLayer")


local Game_Finger = class("Game_Finger", require("app.UI.Game.Game"))

function Game_Finger:ctor(engine, aETC, params)

    cc.SpriteFrameCache:getInstance():removeSpriteFrames()

    --//设置
    self.params = params
    self.aETC = aETC
    self._engine = engine
    local curRule =  engine:curRule()
    local player = xs.sharePlayer()

    
    self._btnAndLineLayer = xs.newBtnAndLineLayer(aETC)
    self._menu = xs.newGameMenu(player.coins, player:expPercent(), player.level, "Menu/Menu.ccbi")
    self._patnLayer = xs.newPatnLayer(curRule:canUsePatns(), curRule:countOfRow()
        ,curRule:countOfColumn(), aETC:getWheelRect())

    self._fireLayer = xs.newFireLayer(aETC, curRule)

    Game_Finger.super:ctor(engine, aETC)

    self._menu:setCallbackObj(self)

    self.fingerPT_BG = nil  --//手指精度条背景
    self.fingerSp    = nil  --//手指背景

    self.spinBoosterPosition = cc.p(170, 45)

end

function Game_Finger:backClick( )
    -- xs.enterScene("MonsterGameScene", {"levelNum" = 1} ,"")

    -- 如果是帮助需要移除帮助
    if self.helperSp ~= nil then
        self.helperSp:runAction(cc.MoveTo:create(0.5, cc.p(display.cx, display.height)))
        self.helperSp = nil
        return
    end


    local params = {}
    params.packageNum = self.params.packageNum

    if self.removeCb then
        self.removeCb()
    end

     -- xs.enterScene("MonsterGameScene", {levelNum = 1} ,"")
     xs.enterScene("GameScene", params, "")
     AudioEngine.playEffect("Sound/btn.wav")
end

function Game_Finger:setRemoveCall(cb)
    self.removeCb = cb
end


function Game_Finger:addAnimalStateMachine()  
    self.animalSM = {}  --动画状态机
    cc.GameObject.extend(self.animalSM):addComponent("components.behavior.StateMachine"):exportMethods() 
  
    self.animalSM:setupState({  
        initial = "none",  
  
  --[[
一局已经结束 开始显示结果
数据显示  
    飞金币
    bigwin提示   有升级提示的情况下 bigwin 将不显示
     升级提示
     线动画  (包含一次所有的) ————> 如果有小游戏,或则免费,就跳过中间的根线条 
             小游戏(如果有) --> 免费转动(如果有) 

one-by-one  获奖的线条显示(如果有,一次所有的) -> 小游戏(如果有) --> 免费转动(如果有)  
--]]
        events = {  
            {name = "showFinger", from = {"none"}, to = "fingerStart"},  
            {name = "finishShowFinger", from = {"fingerStart"}, to = "fingerEnd"},  
            {name = "showBigWin", from = {"fingerEnd"}, to = "bigWinStart"},
            {name = "finishBigWin", from = {"bigWinStart"}, to = "bigWinEnd"},
            {name = "drawAllLine", from = {"bigWinEnd"}, to = "allLineStart"},  
            {name = "finishAllLine", from = {"allLineStart"}, to = "allLineEnd"},  
            {name = "showMiniGame", from = {"allLineEnd"}, to = "miniGameStart"},  
            {name = "finishShowMiniGame", from = {"miniGameStart"}, to = "miniGameEnd"},  
            {name = "showFree", from = {"miniGameEnd"}, to = "showFreeStart"},  
            {name = "finishShowFree", from = {"showFreeStart"}, to = "showFreeEnd"}, 
            {name = "showFreeResult", from = {"showFreeEnd"}, to = "showFreeResultStart"},  
            {name = "finishShowFreeResult", from = {"showFreeResultStart"}, to = "showFreeResultEnd"}, 
            {name = "showLevelUp", from = {"showFreeResultEnd"}, to = "showLevelUpStart"},  
            {name = "finishShowLevelUp", from = {"showLevelUpStart"}, to = "showLevelUpEnd"}, 
            {name = "finish", from = {"showLevelUpEnd"}, to = "none"}, 
        },  

        -- events = {  
        --     {name = "showFinger", from = {"none"}, to = "fingerStart"},  
        --     {name = "finishShowFinger", from = {"fingerStart"}, to = "fingerEnd"},  
        --     {name = "drawAllLine", from = {"fingerEnd"}, to = "allLineStart"},  
        --     {name = "finishAllLine", from = {"allLineStart"}, to = "allLineEnd"},  
        --     -- {name = "showMiniGame", from = {"allLineEnd"}, to = "miniGameStart"},  
        --     -- {name = "finishShowMiniGame", from = {"miniGameStart"}, to = "miniGameEnd"},  
        --     {name = "showFree", from = {"allLineEnd"}, to = "showFreeStart"},  
        --     {name = "finishShowFree", from = {"showFreeStart"}, to = "showFreeEnd"}, 
        --     {name = "finish", from = {"showFreeEnd"}, to = "none"}, 
        -- }, 
  
        callbacks = { 
            onenterfingerStart = function ()  
                self:showFinger()
            end, 

            onenterbigWinStart = function ()  
                self:showAnimalBigWin()
            end, 

            onenterallLineStart = function ()
                -- 这里的调用顺序不能颠倒,应为showAnimalLine处理了状态,所以必须放到最后
                self:changeFingerTP()
                self:showAnimalLine(true)
            end,  

            onenterminiGameStart = function ()  
                self:showAnimalMiniGame()
            end,  
  
            onentershowFreeStart = function ()  
                self:showAnimalFree()
            end,  

            onentershowFreeResultStart = function ()  
                self:showFreeResult()
            end,  

            onentershowLevelUpStart = function ()  
                self:showLevelUp()
            end, 

            onenternone = function ()  
                self:showAnimalLineOneByOne() 
                self:animalEnd()
            end, 
        },  
    })  
end  


function Game_Finger:loopAnimalEvent( ... )
    if self.animalSM:canDoEvent("showFinger") then
        self.animalSM:doEvent("showFinger")
    elseif self.animalSM:canDoEvent("showBigWin") then
        self.animalSM:doEvent("showBigWin")
    elseif self.animalSM:canDoEvent("drawAllLine") then
        self.animalSM:doEvent("drawAllLine")
    elseif self.animalSM:canDoEvent("showMiniGame") then
        self.animalSM:doEvent("showMiniGame")
    elseif self.animalSM:canDoEvent("showFree") then
        self.animalSM:doEvent("showFree")
    elseif self.animalSM:canDoEvent("showFreeResult") then
        self.animalSM:doEvent("showFreeResult")
    elseif self.animalSM:canDoEvent("showLevelUp") then
        self.animalSM:doEvent("showLevelUp")
    elseif self.animalSM:canDoEvent("finish") then
        self.animalSM:doEvent("finish")
    end
end

function Game_Finger:setup()

    self._specialFrameCount = 45
    self._specialFrameInterval =  0.07
    
    -- self._patnLayer:setVisible(false)
    self._putPatnLayer:addChild(self._patnLayer)
    self._putLineBtnLayer:addChild(self._btnAndLineLayer)


    local menuSize = self._menu:getContentSize()
    local visibleSize = cc.Director:getInstance():getVisibleSize()
    local p = cc.p(visibleSize.width * 0.5, visibleSize.height - menuSize.height * 0.5)
    self._menu:align(display.CENTER, p.x, p.y)
              :addTo(self._layer)


    Game_Finger.super:configNodeContainer( self )
    Game_Finger.super:setup()



    ---- 创建手指进度条 和 手指显示的精灵
    self.fingerPT = display.newProgressTimer("fingerPT.png", display.PROGRESS_TIMER_RADIAL)
    self.fingerPT:setPercentage(0)
    self.fingerPT:setAnchorPoint(cc.p(0, 0))

    self.fingerPT_BG:addChild(self.fingerPT)

    local spSize = self.fingerSp:getContentSize() 

    self.fingerSp_Show = display.newSprite("goldWild.png")
    self.fingerSp_Show:setAnchorPoint(cc.p(0.5, 0.5))
    self.fingerSp_Show:setPosition(cc.p(spSize.width * 0.5, spSize.height * 0.5))
    self.fingerSp_Show:setVisible(false)

    self.fingerSp:addChild(self.fingerSp_Show)

end


function Game_Finger:showFinger( ... )

    local fingerPlugin = self._engine:pluginForKey(XSDEPluginFinger_K)
    local fingerResult = fingerPlugin:getResult()

    --// 没有手指
    if  fingerResult.hasFinger == false then
        self.animalSM:doEvent("finishShowFinger")
        self:loopAnimalEvent()
        return
    end

    local curRule =  self._engine:curRule()
    self._fireLayer = xs.newFireLayer(self.aETC, curRule)

    self._putPatnLayer:addChild( self._fireLayer, 100 )
    self._fireLayer:marqueeStartRun( fingerResult.move, function ( ... )

        ---还需要处理finger进度条
        self.fingerPT:setPercentage(0)
        self.fingerSp_Show:setVisible(false)
        self.fingerSp:stopAllActions()

        local scaleX, scaleY = 1, 1

        local indexOfWheel = fingerResult.moveRC.c;
        local rowInWheel = fingerResult.moveRC.r;
        if (self._engine:curRule():countOfColumn() >= indexOfWheel) then

            local wheel = self._patnLayer:getWheel(indexOfWheel);
            scaleX, scaleY = wheel:getScaleXAndY(rowInWheel)

            local point = self.aETC:coverXSPointToPoint(fingerResult.moveRC);  
            local wildSp = display.newSprite("#tiger" .. _V_PIBD_WildPatn .. ".png")
            wildSp:setPosition(point)
            self._putPatnLayer:addChild(wildSp, 10)

            wildSp:runAction(cc.Sequence:create({cc.ScaleBy:create(1.0, 1.3),
                                                 cc.CallFunc:create( function ( ... )
                                                     self._fireLayer:removeFromParent()
                                                 end),
                                                 cc.ScaleBy:create(1.0, 0.7),
                                                 cc.CallFunc:create( function ()
                                                         wheel:changePatn(rowInWheel, _V_PIBD_WildPatn);
                                                         wildSp:removeFromParent()
                                                         self.animalSM:doEvent("finishShowFinger")
                                                         self:loopAnimalEvent()
                                                   end)}
                                                )) 

        else  
            self.animalSM:doEvent("finishShowFinger")
            self:loopAnimalEvent()
        end

    end)

    self.fingerSp:runAction(cc.RepeatForever:create(cc.RotateBy:create(4, 360)))

end


function Game_Finger:changeFingerTP()
    local fingerPlugin = self._engine:pluginForKey(XSDEPluginFinger_K)
    local endPercent = fingerPlugin:getPercent()
    local curPercent = self.fingerPT:getPercentage()

    local endCall = function ( ... )
        if endPercent >= 100 then
            self.fingerSp_Show:setVisible(true)
            self.fingerSp_Show:setOpacity(0.4)
            self.fingerSp_Show:runAction( cc.FadeIn:create(1.0) )
        end
    end

    local  actions = {
        cc.ProgressFromTo:create(1.5, curPercent, endPercent),
        cc.CallFunc:create( endCall)
    }

    self.fingerPT:runAction(cc.Sequence:create(actions))
end


-------------------
--//改变label显示值
function Game_Finger:changeLabelValue()
    
    xs.LabelAutoScale(self._lineLabel, string.format("%d",self._engine:curChip().line), 4.0, 1.0)
    xs.LabelAutoScale(self._lastWinLabel, string.format("%.0f",self._result.winCoins), 15.0, 1.0)
    xs.LabelAutoScale(self._betLabel, string.format("%.0f",self._engine:curChip().bet), 5.0, 1.0)
    xs.LabelAutoScale(self._totalBetLabel, string.format("%.0f",self._engine:curChip():value()),11.0, 1.0)
end

--/*改变按钮状态*/
function Game_Finger:changeBtnStatus(bl)

    Game_Finger.super:changeBtnStatus(bl)

    self._paytableItem:setEnabled(bl)
end



function Game_Finger:paytableItemClick()

    local helperSp = cc.Sprite:create("Helper/Helperbg.png")
    helperSp:setPosition(cc.p(display.cx, display.height))
    helperSp:setAnchorPoint(cc.p(0.5, 0))

    --屏蔽下层按钮事件,如果按钮是通过ccb生成必须这样屏蔽?
    local capture = cc.MenuItemImage:create():size(1140, display.height - 60)
    menu = cc.Menu:create(capture):size(display.size)
    helperSp:addChild(menu)


    self._putMenuLayer:addChild(helperSp, 0)

    helperSp:runAction(cc.MoveTo:create(0.5, cc.p(display.cx, 0)))

    self.helperSp = helperSp
    AudioEngine.playEffect("Sound/btn.wav")
end


xs = xs or {}
function xs.newGame_Finger(...)
    return Game_Finger.new(...)
end

return Game_Finger
