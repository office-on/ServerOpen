-----------------------------------------------------------
-- @@ScriptName: FingerPlugin.lua
-- @@Author: popipo.yr<popipo@foxmail.com>
-- @@Create Date: 2017-04-17 11:07:18
-- @@Modify Date: 2017-04-18 11:08:07
-- @@Function:
-----------------------------------------------------------

require("app.UnitTool.EventPool")
require("Finger.FingerResult")

XSDEPluginFinger_K = "XSDEPluginFinger_K"

local parent = require("app.Data.XSDataEngine.Plugin.XSDataEnginePlugIn")
local FingerPlugin = class("FingerPlugin", parent)

xs = xs or {}
function xs.newFingerPlugin( ... )
    return FingerPlugin.new(...)
end


function FingerPlugin:ctor()

    self.percent = 0   --//当到达1的时候就是拥有finger的时候
    self.result = xs.newFingerResult()

end

function FingerPlugin:key()
    return  XSDEPluginFinger_K
end


function FingerPlugin:stepStart(engine)

    self.result.hasFinger = false
    if self.percent >=  100 then

        self:productFingerRC(engine)
        self.result.hasFinger = true
        self.percent = 0
    end
end


function FingerPlugin:stepEnd(engine)

    local add = (engine._ret.winCoins * 5 / engine:curChip():value()) + 5
    self.percent = self.percent + add

    self.percent = self.percent + 20
end


function FingerPlugin:calcutePatnsOfLineStart(engine, patns, grids, line)

    if self.result.hasFinger == false then  --没有金币
        return nil
    end

    if patns == nil or type(patns) ~= "table" then
        return nil
    end

    local changeGrid = self.result.moveRC

    -- 替换为 wild
    for i = 1, #grids do

        local grid = grids[i]
        if changeGrid.r == grid.r and changeGrid.c == grid.c then
            patns[i] = _V_PIBD_WildPatn
            break
        end
    end

    return patns
end

function FingerPlugin:calcuteAllPatns(engine, patns)

    if self.result.hasFinger == false then  --没有金币
        return nil
    end

    if patns == nil or type(patns) ~= "table" then
        return nil
    end

    local changeGrid = self.result.moveRC
    local rule =  engine:curRule()
    local index = (changeGrid.r - 1) * rule:countOfColumn() + changeGrid.c

    patns[index] = _V_PIBD_WildPatn 

    return patns
end


function FingerPlugin:productFingerRC(engine)

    ----// 走的形状为  从左到右 右转下 再从右到左  
    -----//     ->->->->
    -----//     <-<-<-<-
    -----//     ->->->->

    local rule =  engine:curRule()
    local move = xs.random(1, 10) + 13  --//移动的位置

    -- move = 10

    local everMove = rule:countOfColumn() * rule:countOfRow()
    local lastMove = (move + everMove - 1)  % (everMove) + 1  --//最后一圈的移动

    local moveRow,_ = math.modf((lastMove - 1) / rule:countOfColumn())
    local moveColum = (lastMove + rule:countOfColumn() - 1) % rule:countOfColumn() + 1

    local moveRC = xs.newGridRC(1,1)

    if moveRow % 2 == 0 then  --//移动为偶数则是从左到右
        moveRC.r = rule:countOfRow() - moveRow
        moveRC.c = moveColum
    else
        moveRC.r = rule:countOfRow() - moveRow
        moveRC.c = rule:countOfColumn() - moveColum + 1
    end 

    self.result.move   = move
    self.result.moveRC = moveRC
end


function FingerPlugin:getResult()
    return self.result
end 

function FingerPlugin:getPercent( ... )
    return self.percent
end

return FingerPlugin