-----------------------------------------------------------
-- @@ScriptName: FingerResult.lua
-- @@Author: popipo.yr<popipo@foxmail.com>
-- @@Create Date: 2017-04-17 11:07:18
-- @@Modify Date: 2017-04-18 11:08:07
-- @@Function:
-----------------------------------------------------------

require("app.Data.XSGridRC")

local FingerResult = class("FingerResult")

xs = xs or {}
function xs.newFingerResult( ... )
    return FingerResult.new( ... )
end


function FingerResult:ctor( ... )
   
   self.move =  0 --// 移动步数 
   self.moveRC =  nil --xs.newGridRC(1, 1)　　--//最后结束的位置
   self.hasFinger = false   --//是否拥有手指
 
end





return FingerResult