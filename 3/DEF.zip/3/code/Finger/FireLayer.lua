-----------------------------------------------------------
-- @@ScriptName: BaseMonster.lua
-- @@Author: popipo.yr<popipo@foxmail.com>
-- @@Create Date: 2017-04-17 11:07:18
-- @@Modify Date: 2017-04-18 11:08:07
-- @@Function:  怪物层的展示效果
-----------------------------------------------------------
require("app.Data.XSGridRC")

local FireLayer = class("FireLayer",function()
    return display.newColorLayer(cc.c4b(255,255,0 ,255*0))
end)


xs = xs or {}
function xs.newFireLayer( ... )
    return FireLayer.new( ... )
end

xs.RunStop = 0
xs.RunRight = 1
xs.RunLeft = 2
xs.RunDown = 3
xs.RunUp = 4
    
-- } RunDirect;


function FireLayer:ctor( viewEtc, rule )
    
    self.viewEtc = viewEtc    
    self.rule = rule

        --//设置跑马丁的起点为左上角，方向向右
    self.currentPoint = xs.newGridRC(3, 1)
    self.currentRunDirect = xs.RunRight;
    self._runTime = 0;
    self._keepTime = 0 --// 持续时间

    self._runTimeOut = 0.5
    self._runTimeAdd = 0.1
        

    local  path = cc.FileUtils:getInstance():fullPathForFilename("abc3.ccbi")
    local  proxy = cc.CCBProxy:create()

    -- self.tipParticle  =   CCBReaderLoad(path, proxy)
    self.tipParticle  =   cc.Sprite:create("fire.png")
    self.tipParticle:setPosition(cc.p(-400, 0))
    self.tipParticle:setAnchorPoint( cc.p(0.5, 0.5));
    
    self:addChild(self.tipParticle)
end

function FireLayer:running()

     self:moveTipSpr()
    
    if ( self._runTime >= self._runTimeOut or self._runTime < 0) then
        
        self._runTime = 0;  --//结束,通知代理结束点，并移除层
        self:endPlayActionWithBlock(self.runEndCall)
        return
    end

        
    if self._keepTime > 0 then --//持续时间
        self._keepTime = self._keepTime - 1; 
    else  --//减速阶段
        self._runTime =  self._runTime + self._runTimeAdd;
    end

    self:moveCall()
end

-- ---#pragma mark - 跑马灯
function FireLayer:marqueeStartRun( move, runEndCall )

    self.runEndCall = runEndCall

    self._keepTime = move - (self._runTimeOut / self._runTimeAdd)  - 2 --//持续时间 减去的2为已经移动一次和count多出的一次
    self._runTime = 0;

    local tipSprPoing = self:getGLPointWithrcPoint(self.currentPoint)
    self.tipParticle:setPosition(tipSprPoing)

    self:moveCall()
end

--//移动跑马灯
function FireLayer:moveTipSpr ()
    local tipSprPoing = self:getNextTipSprPointWithCurrentPoint(self.currentPoint)
    self.tipParticle:setPosition(tipSprPoing)
end


function FireLayer:moveCall( )

    local time = self._runTime
    if self._keepTime > 0 then
        time = 0.1
    end

    local animals =  {
    cc.DelayTime:create(time),
    cc.CallFunc:create(handler(self, FireLayer.running)),
    }
    self:runAction(cc.Sequence:create(animals))
end



--//通过行号和列号 获取坐标点 - rwPoint 的x 表示列 ，y 表示行
function FireLayer:getGLPointWithrcPoint( rwPoint)
    return self.viewEtc:coverXSPointToPoint(rwPoint) 
end

---//获取提示精灵的新位置通过传入当前点
function FireLayer:getNextTipSprPointWithCurrentPoint( _currentPoint)

    local tipSprPoint = cc.p(0, 0);

    cases = {
        [xs.RunRight] = function ( ... )

            local c = _currentPoint.c + 1;
            if (c > self.rule:countOfColumn()) then --//已经到一行的右边尽头

                print(r)
                print(self.rule:countOfRow())
                
                self.currentRunDirect =  xs.RunDown;
                tipSprPoint = self:getNextTipSprPointWithCurrentPoint(_currentPoint)
                
            else 
                
                _currentPoint.c = _currentPoint.c + 1; 
                tipSprPoint = self:getGLPointWithrcPoint(_currentPoint);
            end
        
        end,
        
        [xs.RunLeft] = function ( ... )
        
            local c = _currentPoint.c - 1;
            if (c < 1) then
                self.currentRunDirect =  xs.RunDown;
                tipSprPoint = self:getNextTipSprPointWithCurrentPoint(_currentPoint)
            else 
                _currentPoint.c = _currentPoint.c - 1; 
                tipSprPoint = self:getGLPointWithrcPoint(_currentPoint);
            end
        end,
        
        [xs.RunDown] = function ( ... )
        
            local r = _currentPoint.r - 1;
            
            if (r < 1) then --//表示为最后一行，并且开始向下,则恢复道起始点
                
                _currentPoint.r = 3;
                _currentPoint.c = 1;
                self.currentRunDirect =  xs.RunRight;
            else 
                _currentPoint.r  = _currentPoint.r - 1;

                if _currentPoint.c == 1 then
                    self.currentRunDirect = xs.RunRight
                else   
                    self.currentRunDirect = xs.RunLeft
                end
                
            end
            
            tipSprPoint = self:getGLPointWithrcPoint(_currentPoint);
        end, 
    }

    local casesCall = cases[self.currentRunDirect]
    casesCall()
    
    self.currentPoint = _currentPoint
    
    return tipSprPoint;
    
end



---//结束时的动画
function FireLayer:endPlayActionWithBlock(block)
    
    if block ~= nil then
        block()
    end 
   
    self.tipParticle:runAction(cc.ScaleBy:create(1.0, 1.3))
end




-- - (void) stopWithEndPoint:(CGPoint) endPoint;    //结束的标志

        

return FireLayer