-----------------------------------------------------------
-- @@ScriptName: GameMenu_Boom.lua
-- @@Author: popipo.yr<popipo@foxmail.com>
-- @@Create Date: 2014-07-17 10:05:52
-- @@Modify Date: 2014-07-22 14:29:17
-- @@Function:
-----------------------------------------------------------
require("app.UI.Menu.RootMenu")
local GameMenu_Boom = class("GameMenu_Boom", function ()
    local  layer = display.newLayer()
    layer:setTouchEnabled(false)
    return layer
end)

xs = xs or {}
function xs.newGameMenu_Boom(...)
    return GameMenu_Boom.new(...)
end

function GameMenu_Boom:ctor(...)
    self._rootMenu = xs.newRootMenu(...)
    local size = self._rootMenu:getContentSize()
    self:setContentSize(size)

    self._rootMenu.setItem:setEnabled(false)
    self._rootMenu.setItem:setVisible(false)
    self._rootMenu:operationCallback(self)

    local setSize = self._rootMenu.setItem:getContentSize()
    local setPoint = cc.p(self._rootMenu.setItem:getPosition())


    local backPoint = setPoint
    local paytablePoint = cc.p(backPoint.x - setSize.width - 5, backPoint.y)

    
    self:addChild(self._rootMenu)

    cc.ui.UIPushButton.new({normal = "Menu_Boom/_back.png", pressed = "Menu_Boom/_backSel.png"})
        :align(display.CENTER, backPoint.x, backPoint.y)
        :onButtonClicked(function()
                 self:backCall()
            end)
        :addTo(self._rootMenu)

    cc.ui.UIPushButton.new({normal = "Menu_Boom/_help.png", pressed = "Menu_Boom/_helpSel.png"})
        :align(display.CENTER, paytablePoint.x, paytablePoint.y)
        :onButtonClicked(function()
                 self:helpCall()
            end)
        :addTo(self._rootMenu)
end

function GameMenu_Boom:setInfo(coins, exp_percent, level, addExp)
    self._rootMenu:setInfo(coins, exp_percent, level, addExp)
end

function GameMenu_Boom:openStore(paymentShow)
    self._rootMenu:openStore(paymentShow)
end

function GameMenu_Boom:openStore_cb(store)
    store:rotation(90)
    store:setAnchorPoint(cc.p(0, 1))
    store:ignoreAnchorPointForPosition(false)
    store:setPosition(cc.p(display.height, self._rootMenu:getBtnHeight()))
end

function  GameMenu_Boom:coinsShowPoint()
    return self._rootMenu:coinsShowPoint()
end

function GameMenu_Boom:backCall()
     if self.cb_obj and self.cb_obj.backClick then
        self.cb_obj:backClick()
    end
end

function GameMenu_Boom:helpCall()
     if self.cb_obj and self.cb_obj.helpClick then
        self.cb_obj:helpClick()
    end
end

function GameMenu_Boom:setCallbackObj(cb)
    self.cb_obj = cb
end


return GameMenu_Boom
