
local BoomLayer = class("BoomLayer", function ( ... )
	return display.newLayer()
end)

xs = xs or {}
xs.newBoomLayer = function ( ... )
	return BoomLayer.new(...)
end

--//-----------------------------------------
-- self.m_ix = 100.0
--  self.m_ixadd = 110.0
--   self.m_iy = 230.0
--    self.m_iyadd = 80.0
--//-----------------------------------------

function BoomLayer:ctor(boomMap, boomSystem, freshObj)

	print(boomMap)
	print(boomSystem)

	self.m_cXSTMap = boomMap
	-- self.m_cXSTMap:setRows(4)
	self.m_cXSTSystem = boomSystem
	self.m_cXSTSystem:reset()

	self.m_vSStones = {}
	self.m_notDelStones = {} --//这个数据是m_vSStones的对应值,但是不会被删除
	

	self.m_bDoneBomb = true
	self.m_bDropStones = true
	self.m_bAllStones = true


	self.freshCB = handler(freshObj, freshObj.freshCB)

	self.m_msSawtooth = {}  --//不规则边缘

	self._ret = nil


end



function	BoomLayer:initConfig(rect)

	cc.SpriteFrameCache:getInstance():addSpriteFrames("bomb/TPbomb.plist");
	self.m_cFloor = cc.Sprite:createWithSpriteFrameName("floor.png");
	self.m_floorSize = self.m_cFloor:getContentSize()

	
	self.m_ixadd = rect.width / self.m_cXSTMap:getColumns()   --//x方向每个方格增加值
    self.m_ix = rect.x + self.m_ixadd*0.5                     --//x方向方格起点
	
	self.m_iyadd = (rect.height - self.m_floorSize.height)  / (self.m_cXSTMap:getRows() - 1)     --//y方向每个方格增加值
    self.m_iy = rect.y  + self.m_floorSize.height     --//y方向方格起点
    
    self.m_cRect = rect

    self.m_cFloor:setPosition(cc.p( cc.rectGetMidX(self.m_cRect), cc.rectGetMinY(self.m_cRect) + self.m_floorSize.height * 0.5))
	self:addChild(self.m_cFloor)

    self:initAllStones()
    self:addAllStone()
    self:updataSawtooth()
end

function BoomLayer:changeScaleX(sprite)
	local  scaleX = self.m_ixadd / sprite:getContentSize().width;
    sprite:setScaleX(scaleX);
end

function BoomLayer:changeScaleY(sprite)
	local  scaleY = self.m_iyadd / sprite:getContentSize().height;
    sprite:setScaleY(scaleY);
end

function BoomLayer:setStonePosition(stone, column, row)
	---///row - 1 - 1 中 再减去1是地板的高度
	local point = self:getStonePosition(column, row)
	stone:setPosition(point)
end

function BoomLayer:getStonePosition(column, row)

	---///row - 1 - 1 中 再减去1是地板的高度
	local point = cc.p((column - 1) * self.m_ixadd + self.m_ix, 
		              (row - 1)* self.m_iyadd + self.m_iy - self.m_floorSize.height) 

	if row == 1 then ---这里是地板
		point.y =  self.m_iy - self.m_floorSize.height*0.5
	end
	return point
end


function BoomLayer:changeFloorObjScaleY(sprite, floor)
	local  scaleY = floor:getContentSize().height / sprite:getContentSize().height;
    sprite:setScaleY(scaleY);
end

function BoomLayer:setFloorObjPosition(stone, column, row, floor)
	stone:setPosition(cc.p((column - 1) * self.m_ixadd + self.m_ix, 
						   (row - 1) * self.m_iyadd + cc.rectGetMinY(self.m_cRect) + floor:getContentSize().height * 0.5))
end


function BoomLayer:setHorPosition(stone, column, row)
	---///row - 1 - 1 中 再减去1是地板的高度
	local point = cc.p((column - 1) * self.m_ixadd + self.m_ix,
					   (row - 1)* self.m_iyadd + self.m_iy  - self.m_iyadd * 0.5 - self.m_floorSize.height) 
	stone:setPosition(point)
end

function BoomLayer:setVecPosition(stone, column, row, isFlipY)
	---///row - 1 - 1 中 再减去1是地板的高度
	local add = isFlipY and (self.m_ixadd * 0.5) or (self.m_ixadd * -0.5)

	local point = cc.p((column - 1) * self.m_ixadd + self.m_ix + add,
					  (row - 1)* self.m_iyadd + self.m_iy -self.m_floorSize.height)
	stone:setPosition(point)
end

function BoomLayer:initAllStones()

	cc.SpriteFrameCache:getInstance():addSpriteFrames("bomb/TPbomb.plist");

	-- self.m_cFloor = cc.Sprite:createWithSpriteFrameName("floor.png");

	self.m_vSStones = {}
	self.m_notDelStones = {}
	self.m_cFloor:setVisible(true);

	for column =1, self.m_cXSTMap:getColumns() do
		for row =1, self.m_cXSTMap:getRows() do

			local point = xs.newXSTPoint(column, row)
            local aObj = self.m_cXSTMap:getObj(point)

            local cSprite = nil
            if aObj.type == xs.XSTOOType_NULL then   ---//用空白代替
            	cSprite = cc.Sprite:createWithSpriteFrameName("ore" .. 8 .. ".png")
            else
            	cSprite = cc.Sprite:createWithSpriteFrameName("ore" .. aObj.type .. ".png")
            end

			-- local cSprite = cc.Sprite:createWithSpriteFrameName("ore" .. aObj.type .. ".png")
			self:changeScaleX( cSprite )

			-- local node = cc.Node:create()
			-- node:addChild(cSprite)

			if (aObj.type == xs.XSTOOType_Floor) then
				self:changeFloorObjScaleY(cSprite, self.m_cFloor)
				self:setFloorObjPosition(cSprite, column, row, self.m_cFloor)
			else
				self:changeScaleY(cSprite)
				self:setStonePosition(cSprite, column, row)
			end

			table.insert(self.m_vSStones ,cSprite)
			table.insert(self.m_notDelStones ,cSprite)
		end
	end 
end 

function BoomLayer:addAllStone()
	for i, stone in ipairs(self.m_vSStones) do
		stone:setTag(i)
		self:addChild(stone)
	end
end


function BoomLayer:updataSawtooth()

	cc.SpriteFrameCache:getInstance():addSpriteFrames("bomb/TPbomb.plist");

	for _, sawtTooth in ipairs(self.m_msSawtooth) do
		self:removeChild(sawtTooth)
	end

	self.m_msSawtooth = {}

	local iup = 0;

	for column =1, self.m_cXSTMap:getColumns() do
		iup = 0;
		for row =1, self.m_cXSTMap:getRows() do

			local point = xs.newXSTPoint(column, row)
            local aObj = self.m_cXSTMap:getObj(point)

			if (aObj.type == xs.XSTOOType_NULL) then

				if (iup == 0) then
					iup = iup + 1;
					local ro = row - 1;
					if (ro >= 1) then

						local point = xs.newXSTPoint(column, ro)
            			local aObj1 = self.m_cXSTMap:getObj(point)

						if (aObj1.type ~= xs.XSTOOType_Floor) then
						
							local cSprite = cc.Sprite:createWithSpriteFrameName("UpSawtooth.png");
							self:changeScaleX(cSprite)
							self:setHorPosition(cSprite, column, row)

							table.insert(self.m_msSawtooth, cSprite);
						end
					end
				end
				
				if true then
					local col = column - 1;
					if (col >= 1) then
					
						local point = xs.newXSTPoint(col, row)
            			local aObj1 = self.m_cXSTMap:getObj(point)

						if (aObj1.type ~= xs.XSTOOType_NULL and aObj1.type ~= xs.XSTOOType_Count) then
						
							local cSprite = cc.Sprite:createWithSpriteFrameName("OrSoSawtooth.png");
							self:changeScaleY(cSprite)
							self:setVecPosition(cSprite, column, row)

							table.insert(self.m_msSawtooth, cSprite);
						end
					end
				end
				if true  then
					local col = column + 1;
					if (col <= self.m_cXSTMap:getColumns()) then
					
						local point = xs.newXSTPoint(col, row)
            			local aObj1 = self.m_cXSTMap:getObj(point)

						if (aObj1.type ~= xs.XSTOOType_NULL and aObj1.type ~= xs.XSTOOType_Count) then
						
							local cSprite = cc.Sprite:createWithSpriteFrameName("OrSoSawtooth.png");
							self:changeScaleY(cSprite)
							cSprite:setFlippedY(true);
							self:setVecPosition(cSprite, column, row, true)

							table.insert(self.m_msSawtooth, cSprite);
						end
					end
				end
			
			else 
			
				if (row == self.m_cXSTMap:getColumns()) then
				
						local cSprite = cc.Sprite:createWithSpriteFrameName("UpSawtooth.png");
						self:changeScaleX(cSprite)
						self:setHorPosition(cSprite, column, row+1)

						table.insert(self.m_msSawtooth, cSprite);
				end
			end
		end
	end


	for _, sawtTooth in ipairs(self.m_msSawtooth) do
		self:addChild(sawtTooth)
	end
end


function BoomLayer:dropStones()
	if (self.m_bDropStones == false) then
		return
	end

	for column =1, self.m_cXSTMap:getColumns() do
		for row =1, self.m_cXSTMap:getRows() do

			local point = xs.newXSTPoint(column, row)
            local aObj = self.m_cXSTMap:getObj(point)

				if (aObj.type ~= xs.XSTOOType_Floor)  then--// XSTreasureObjData:XSTOOType:XSTOOType_Floor)
				
					local cSprite = self:getThing(column, row)

					cSprite:runAction(cc.Sequence:create({
						cc.MoveTo:create(1.0, cc.p(cSprite:getPositionX(), cSprite:getPositionY() - self.m_cXSTMap:getRows() * 80.0 - 230.0)),
						cc.MoveTo:create(2.0, cc.p(cSprite:getPositionX(), cSprite:getPositionY())),
						}))
				end 
			end 
		end 

		self.m_bDropStones = false
	
end 

function BoomLayer:dropStonesBack()
	self.m_bDoneBomb = true
	self.m_bDropStones = true
	self.m_bAllStones = true
end

function BoomLayer:onCallback(bomPoint, ret, scaleX, scaleY)

	if ret == nil then
		return
	end
	
	self._ret = ret
		local  cXSTPoint = self._ret.boomAt
		local  cPoint = self:getStonePosition(cXSTPoint.column, cXSTPoint.row)

		self.m_cSBomb = cc.Sprite:create("bomb.png")
		self:addChild(self.m_cSBomb)
		self.m_cSBomb:setScaleX(scaleX)
		self.m_cSBomb:setScaleY(scaleY)
		self.m_cSBomb:setPosition(bomPoint)

		self.m_cSBomb:runAction(cc.Sequence:create({
			cc.ScaleTo:create(1.0, 0.6),
			}));
		self.m_cSBomb:runAction(cc.Sequence:create({
			cc.RotateBy:create(1.0, 360),
			}));
		self.m_cSBomb:runAction(cc.Sequence:create({
			cc.EaseSineIn:create(cc.MoveTo:create(1.0, cPoint)),
			cc.CallFunc:create( handler(self, BoomLayer.runBombEffectAction) ),
			cc.RemoveSelf:create(true),
			}));
	
end 


function BoomLayer:runBombEffectAction()

    AudioEngine.playEffect("bomb/bomb.wav");
    
	local  cXSTPoint = self._ret.boomAt
	local  cPoint = self:getStonePosition(cXSTPoint.column, cXSTPoint.row)

	if true then
		local cParticleSystemQuad = cc.ParticleSystemQuad:create("bomb/burstFlare.plist");
		cParticleSystemQuad:setPosition(cPoint);
		self:addChild(cParticleSystemQuad,99);

		cParticleSystemQuad:setScale(0.8);

		cParticleSystemQuad:runAction(cc.Sequence:create({
			cc.CallFunc:create( handler(self, BoomLayer.runCoinsAction) ),
			cc.DelayTime:create(cParticleSystemQuad:getDuration()),
			cc.RemoveSelf:create(true),
			}));
	end

	if true then
	
		local cParticleSystemQuad = cc.ParticleSystemQuad:create("bomb/growingFlare.plist");
		cParticleSystemQuad:setPosition(cPoint);
		self:addChild(cParticleSystemQuad, 99);

		cParticleSystemQuad:setScale(0.5);

		cParticleSystemQuad:runAction(cc.Sequence:create({
			cc.DelayTime:create(cParticleSystemQuad:getDuration()),
			cc.RemoveSelf:create(true),
			}));
	end	

    self:runAction(XSShake:create(0.6, 7))
    
    local tag = (cXSTPoint.column - 1) * self.m_cXSTMap:getRows() + cXSTPoint.row 
    table.removebyvalue(self.m_vSStones, self:getThing(cXSTPoint.column, cXSTPoint.row))
	self:removeChildByTag(tag);

end



function BoomLayer:runCoinsAction()
	-- cc.SpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("bomb/TPbomb.plist", "bomb/TPbomb.png");


	local  cXSTPoint = self._ret.boomAt
	local aObj = nil

    for i, rcPoint  in ipairs(self._ret.retBoomPoint) do
    	if rcPoint:equalTo(cXSTPoint) then 

    	   aObj = self._ret.retObjs[i]
    	   break
    	end	
    end



	local cPoint = cc.p((cXSTPoint.column - 1) * self.m_ixadd + self.m_ix, (cXSTPoint.row - 1 - 0.5)* self.m_iyadd + self.m_iy)

	local runing = {

 		[xs.XSTOOType_Coins] = function  ()

			local cLCoins = cc.LabelBMFont:create("+" .. aObj.number, "bomb/bombfont.fnt");
			cLCoins:setPosition(cPoint);
			cLCoins:setScale(0.8);
			self:addChild(cLCoins , 199);

			cLCoins:runAction(cc.Sequence:create({
				cc.ScaleTo:create(0.5, 1.0),
				cc.DelayTime:create(0.5),
				cc.RemoveSelf:create(true),
				}));
		end,

		[xs.XSTOOType_X2] =  function  ()
	
			local cSprite = cc.Sprite:createWithSpriteFrameName("x2.png");
			cSprite:setPosition(cPoint);
			cSprite:setScale(0.3);
			self:addChild(cSprite , 199);

			cSprite:runAction(cc.Sequence:create({
				cc.ScaleTo:create(0.5, 0.6),
				cc.DelayTime:create(0.5),
				cc.RemoveSelf:create(true),
				}));
		
		end,

		[xs.XSTOOType_X3] = function ()

			local cSprite = cc.Sprite:createWithSpriteFrameName("x3.png");
			cSprite:setPosition(cPoint);
			cSprite:setScale(0.3);
			self:addChild(cSprite , 199);

			cSprite:runAction(cc.Sequence:create({
				cc.ScaleTo:create(0.5, 0.6),
				cc.DelayTime:create(0.5),
				cc.RemoveSelf:create(true),
				}));
		end,

		[xs.XSTOOType_X4] = function ()
		
			local cSprite = cc.Sprite:createWithSpriteFrameName("x4.png");
			cSprite:setPosition(cPoint);
			cSprite:setScale(0.3);
			self:addChild(cSprite , 199);

			cSprite:runAction(cc.Sequence:create({
				cc.ScaleTo:create(0.5, 0.6),
				cc.DelayTime:create(0.5),
				cc.RemoveSelf:create(true),
				}));
		end,

		[xs.XSTOOType_X5] = function ()

			local cSprite = cc.Sprite:createWithSpriteFrameName("x5.png");
			cSprite:setPosition(cPoint);
			cSprite:setScale(0.3);
			self:addChild(cSprite , 199);

			cSprite:runAction(cc.Sequence:create({
				cc.ScaleTo:create(0.5, 0.6),
				cc.DelayTime:create(0.5),
				cc.RemoveSelf:create(true),
				}));
		end,
	
		[xs.XSTOOType_Nothing] = function ()
		
			local cSprite = cc.Sprite:create();
			cSprite:setPosition(cPoint);
			self:addChild(cSprite);

			cSprite:runAction(cc.Sequence:create({
				cc.DelayTime:create(1.0),
				cc.RemoveSelf:create(true),
				}));
		end,
	}


	local aRunning = runing[aObj.type]
	if aRunning then
		aRunning()
		self:updatePlayerInfo(aObj)
	end

	if (aObj.type ~= xs.XSTOOType_Floor) then
		self:updataSawtooth()
	else
		self:overrr()
	end
end

function BoomLayer:updatePlayerInfo(aObj)

    local player = xs.sharePlayer()

    if aObj.type == xs.XSTOOType_Coins  then 
        player:addCoins(aObj.number)
        ---通知金币发生变化
        xs.shareEventPool():dispatchEvent(xs.event.CoinsChange) 
    else
        local number = player:getBoosterNumber(aObj.type) + aObj.number
        player:setBoosetNumber(aObj.type, number) 
    end 
end


function BoomLayer:overrr( )

	local  m_iyadd = self.m_iyadd * self.m_cXSTMap:getRows()

		for i, cSawtooth  in ipairs(self.m_msSawtooth) do
			cSawtooth:runAction(cc.Sequence:create({
				cc.DelayTime:create(0.5),
				cc.MoveTo:create(0.5, cc.p(cSawtooth:getPositionX(), cSawtooth:getPositionY() - m_iyadd)),
				cc.RemoveSelf:create(true),
				}));
		end
		self.m_msSawtooth = {}

		self.m_cFloor:runAction(cc.Sequence:create({
			cc.DelayTime:create(3.0),
			cc.CallFunc:create( handler(self, BoomLayer.isFloorBroken) ),
			-- cc.RemoveSelf:create(true),
			}));
		self.m_cFloor:setVisible(false);

		for i, stone in ipairs(self.m_vSStones) do

			local point = cc.p(stone:getPositionX(), stone:getPositionY())
			point.y = point.y - m_iyadd 

			stone:runAction(cc.Sequence:create({
				cc.DelayTime:create(0.5),
				cc.MoveTo:create(0.5, cc.p(point)),
				cc.RemoveSelf:create(true),
				}));
		end

		self.m_vSStones = {}
		self.m_notDelStones = {}
		
end


function BoomLayer:isFloorBroken()

	local m_iMapRow =  self.m_cXSTMap:getRows()

	if (self._ret.isOver) then
		

	    self:initAllStones()
    	self:addAllStone()
    	self:updataSawtooth()

		for i, cSBlock in ipairs(self.m_vSStones) do

			cSBlock:setPosition(cc.p(cSBlock:getPositionX(), cSBlock:getPositionY() - self.m_iyadd * m_iMapRow));
			cSBlock:runAction(cc.Sequence:create({
				cc.MoveTo:create(1.5, cc.p(cSBlock:getPositionX(), cSBlock:getPositionY() + self.m_iyadd * m_iMapRow)),
				}));
		end

		self.m_cFloor:setPosition(cc.p(self.m_cFloor:getPositionX(), self.m_cFloor:getPositionY() - self.m_iyadd * m_iMapRow));
		self.m_cFloor:runAction(cc.Sequence:create({
			cc.MoveTo:create(1.5, cc.p(self.m_cFloor:getPositionX(), self.m_cFloor:getPositionY() + self.m_iyadd * m_iMapRow)),
			}));


		for i, cSawtooth  in ipairs(self.m_msSawtooth) do
		
			cSawtooth:setPosition(cc.p(cSawtooth:getPositionX(), cSawtooth:getPositionY() - self.m_iyadd * m_iMapRow));
			cSawtooth:runAction(cc.Sequence:create({
				cc.MoveTo:create(1.5, cc.p(cSawtooth:getPositionX(), cSawtooth:getPositionY() + self.m_iyadd * m_iMapRow)),
				}));
		end

		self:runAction(cc.Sequence:create({
						cc.DelayTime:create(2.0),
						cc.CallFunc:create(function ()
								self.freshCB()
						end)
					  }))
		
		self.m_cFloor:setVisible(true);
	end
end


function BoomLayer:getThing(column, row )
	local cSprite = self.m_notDelStones[(column - 1) * self.m_cXSTMap:getRows() + row]
	return cSprite
end