-----------------------------------------------------------
-- @@ScriptName: Hero.lua
-- @@Author: popipo.yr<popipo@foxmail.com>
-- @@Create Date: 2017-5-17 13:51:22
-- @@Modify Date: 2017-5-25 15:09:52
-- @@Function:
-----------------------------------------------------------
require("Boom.BoomObjs")

local BoomMapData = class("BoomMapData")

function BoomMapData:ctor( ... )

	--/*纵向储存 左下角第一个点  右上角最后一个点*/
	self.mapObjs = {}   --[[BoomObj ...]  , ... ,  [BoomObj ...]]
	self.columns = 0 --//行数
    self.rows = 0  --//列数
end

function BoomMapData:getObjAt(aXSTPoint)
	local rowData = self.mapObjs[aXSTPoint.column]
	local obj = rowData[aXSTPoint.row]
	return obj
end

function BoomMapData:clear()
	self.mapObjs = {}
end

function BoomMapData:addRowDatas(data, row)
	table.insert(self.mapObjs, row, data)
end

xs = xs or {}
xs.newBoomMapData =  function ( ... )
	return BoomMapData.new(...)
end


return BoomMapData