-----------------------------------------------------------
-- @@ScriptName: BoomPlugin.lua
-- @@Author: popipo.yr<popipo@foxmail.com>
-- @@Create Date: 2017-04-17 11:07:18
-- @@Modify Date: 2017-04-18 11:08:07
-- @@Function:
-----------------------------------------------------------

require("app.UnitTool.EventPool")

XSDEPluginBoom_K = "XSDEPluginBoom_K"
XSBoomPatn = "1000" 

local parent = require("app.Data.XSDataEngine.Plugin.XSDataEnginePlugIn")
local BoomPlugin = class("BoomPlugin", parent)

xs = xs or {}
function xs.newBoomPlugin( ... )
    return BoomPlugin.new(...)
end


function BoomPlugin:ctor( boomSystem, boomMap )

    self.boomSystem = boomSystem
    self.boomMap = boomMap

    self.cur = 0   --//当前次数
    self.per = 3   --//多少次出现炸弹

    self.hasBomb = false
    self.from = nil

    self.ret = nil

end

function BoomPlugin:key()
    return  XSDEPluginBoom_K
end

-- 替换一个为炸弹,返回新的数据
--[[
--]]
function BoomPlugin:calcutePatns(engine, patns)

    if patns == nil or type(patns) ~= "table" then
        return nil
    end

    local rule = engine:curRule()

     ----///计算需要的炸弹位置 修改patn 
    self.cur = self.cur + 1 ;
    
    if (self.cur % self.per == 0)  then
        
        self.cur = 0;
        self.per = xs.random(0,2) + 3 ;
        
        local changePoint = -1;
        
        --/*替换一个图标为炸弹图标*/
        if ( #patns > 0) then
            changePoint = xs.random(1, #patns);
            patns[changePoint] = XSBoomPatn;
        end

        -- changePoint = 1

        ---/*炸弹的列行*/
        local from = xs.newBoomFrom()
        from.column = math.modf((changePoint - 1) / rule:countOfRow()) + 1
        from.row = (changePoint - 1) % rule:countOfRow() + 1
        from.direct = xs.BoomFromDirect_Default


       print("------------------------------")
       print(changePoint .. " ccc " .. from.column .. " ssss ".. from.row)

        self.from = from
        self.hasBomb = true;
        
    else
        self.from = nil
        self.hasBomb = false;
    end

    return patns
end


----/*计算结果*/
function BoomPlugin:stepEnd(engine)
    
    self.ret = nil
    
    if (self.hasBomb) then
        
        local abomb =  xs.newNormalBomb()
        local ret = self.boomSystem:boom(self.from, abomb);

        local rcpoint = {}
        rcpoint.c = self.from.column
        rcpoint.r = self.from.row

        ret.rcpoint = rcpoint 
        -- ret.boomAt = rcpoint
                     
        self.ret = ret
        
        --//添加道具
        
        -- for (itr = resultObj.begin(); itr != resultObj.end(); itr++) {
            
        --     XSTreasureObject obj = *itr;
            
            
            
        --     switch (obj.type) {
        --         case XSTreasureObject::XSTOOType_X2:{
                    
        --             XSInfo::shareBooster()->addBoosterNumber(XSBoosterX2, 1);
                    
        --         }
                    
        --             break;
                    
        --         case XSTreasureObject::XSTOOType_X3:{
                    
        --             XSInfo::shareBooster()->addBoosterNumber(XSBoosterX3, 1);
        --         }
                    
        --             break;
                    
        --         case XSTreasureObject::XSTOOType_X4:{
                    
        --             XSInfo::shareBooster()->addBoosterNumber(XSBoosterX4, 1);
        --         }
                    
        --             break;
                    
        --         case XSTreasureObject::XSTOOType_X5:{
                    
        --             XSInfo::shareBooster()->addBoosterNumber(XSBoosterX5, 1);
        --         }
                    
        --             break;
                    
        --         case XSTreasureObject::XSTOOType_WILD:{
                    
        --             XSInfo::shareBooster()->addBoosterNumber(XSBoosterSilver, 1);
        --         }
                    
        --             break;
                    
                    
        --         case XSTreasureObject::XSTOOType_Coins:{
                    
        --             XSInfo::sharePlayerInfo()->setCoins(XSInfo::sharePlayerInfo()->getCoins()+obj.number);
        --         }
                    
        --             break;
                    
        --         default:
        --             break;
        --     }
        
    end 
end




function BoomPlugin:getBoomResult()

    print( "slllllllllllllllllllll")
    print(self.ret)
    return self.ret
end


return MonsterLoop