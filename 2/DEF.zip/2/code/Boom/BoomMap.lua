-----------------------------------------------------------
-- @@ScriptName: Hero.lua
-- @@Author: popipo.yr<popipo@foxmail.com>
-- @@Create Date: 2017-5-17 13:51:22
-- @@Modify Date: 2017-5-25 15:09:52
-- @@Function:
-----------------------------------------------------------

require("Boom.BoomMapData")

local BoomMap = class("BoomMap")

function BoomMap:ctor( ... )

	self.pMapData = xs.newBoomMapData()   -- BoomMapData
	self.pMapData.columns = 5 
    self.pMapData.rows = 5 
end


--/*是否为空隙*/
function BoomMap:isGap( p)
    local aObj = self:getObj(p) 
    return (aObj.type == xs.XSTOOType_NULL)
end	
    
--/*获取一个点的奖励*/
function BoomMap:getObj( p)  --XSTreasureObject
	return self.pMapData:getObjAt(p) 
end

function BoomMap:getColumns()  --
	return self.pMapData.columns 
end

function BoomMap:getRows()  --
	return self.pMapData.rows 
end
    
--/*移除一个点*/
function BoomMap:removeGap( p)
	local aObj = self:getObj(p) 
    aObj.type = xs.XSTOOType_NULL   --//改为变成空隙
end	
    
--/*reset*/
function BoomMap:reset()
    
	self.pMapData:clear()
    
    for row = 1, self.pMapData.rows do

		local  aRowObjs = {}

		for column = 1, self.pMapData.columns  do

			local aObj = xs.newMapCellObj() 
            aObj.number = 1 
            
            if column == 1 then
                aObj.type = xs.XSTOOType_Floor 
            else
                local k = 0 
                repeat
                	k = k + 1
                	if k > 6 then
                		aObj.type = xs.XSTOOType_Nothing 
                        break
                	end

                	aObj:randomType()
                
                until (aObj.type ~= xs.XSTOOType_Floor)

                -- aObj.type = xs.XSTOOType_NULL
            end

            table.insert(aRowObjs, aObj)
            
            if aObj.type == xs.XSTOOType_NULL then --//空隙则结束 改为全设置为空
                
                for i=(column + 1), self.pMapData.columns do
                	local aObj = xs.newMapCellObj()
                    aObj.type = xs.XSTOOType_NULL 
                    aObj.number = 1 
                     table.insert(aRowObjs, aObj)
                end
                
                break --退出這一列的數據生成
            end
        end
		self.pMapData:addRowDatas(aRowObjs, row)        
    end
end
    
--/*获取一个物件属性*/
function BoomMap:objProperty( p ,  aObj) --bool
-- function objProperty( p , XSTreasureObject& aObj) --bool

-- 	/*获取一个物件属性*/
-- bool XSTreasureMap::objProperty(const XSTPoint& p , XSTreasureObject& aObj){
    
--     bool ret = false 
    
--     try {
        
--         aObj =  pMapData->mapObjs.at(p.column).at(p.row) 
        
--         ret = true 
        
--     } catch (std::exception& e){} 
    
--     return ret 

-- }
end   
    
--/*设置OBJ 标量值*/
function BoomMap:setObjScalar( value)
end 
    
---/*test--显示当前地图*/
function BoomMap:show()

	for row = 1, self.pMapData.rows do

		local typeStr = ""

		for column = 1, self.pMapData.columns do

			local point = xs.newXSTPoint(column, row)
            local aObj = self:getObj(point)

            typeStr = typeStr .. aObj.type .. "|"
        end
		print(typeStr)        
    end
    
    print("----------------")
end   
    
xs.newBoomMap = function ( ... )
	return BoomMap.new(...)
end


return BoomMap
