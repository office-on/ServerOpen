xs = xs or {}

--//炸弹
local Boom = class("Boom")

-- 子類需要實現的方法
--//爆炸方式  输入一个爆炸位置，和地图行列 返回爆炸的点 
function Boom:boomStyle(atPoint, columns , rows)
    return {}
end


--//普通炸弹
local NormalBomb = class("NormalBomb", Boom)

--只影響當前位置
function NormalBomb:boomStyle(atPoint, columns , rows)
    return {atPoint}
end

xs.newNormalBomb = function ( ... )
    return NormalBomb.new(...)
end

return Boom, NormalBomb