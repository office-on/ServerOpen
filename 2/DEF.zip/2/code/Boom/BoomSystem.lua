-----------------------------------------------------------
-- @@ScriptName: Hero.lua
-- @@Author: popipo.yr<popipo@foxmail.com>
-- @@Create Date: 2017-5-17 13:51:22
-- @@Modify Date: 2017-5-25 15:09:52
-- @@Function:
-----------------------------------------------------------
require("Boom.BoomMap")
require("Boom.Bomb")


local BoomSystem = class("BoomSystem")

xs = xs or {}
xs.newBoomSystem = function ( map )
	return BoomSystem.new( map )
end

function BoomSystem:ctor( map)
	self.pMap =  map --//or xs.newBoomMap()
end



--/*boom
 -- -- 这里的row 防止修改 旁边出入
 -- -- 返回爆炸的位置和奖励
 -- */

-- void XSTreasureSystem::boom(XSTreasureBoomFrom from, XSTreasureBomb* pBomb, XSTPoint& boomAt,
--                             std::vector<XSTreasureObject>& retObjs, std::vector<XSTPoint>& retBoomPoint
--                             ,bool& isOver){
function BoomSystem:boom_(from, pBomb)
    
    local ret = {}
    
    ret.isOver = false 

    --//计算爆炸点 遇到不是空隙的地方就爆炸
    ret.boomAt = self:calcBoomPoint(from.direct, from.column) 
    
    if (ret.boomAt == xs.XSTPointNull) then
        ret.isOver = true 
        return ret 
    end


    --//通过炸弹的爆炸方式，获取炸毁的点
    local boomIns = pBomb:boomStyle(ret.boomAt, self.pMap:getColumns(), self.pMap:getRows()) 
    
    --//获取需要爆炸的点
    --//获取赢得的物件
    ret.retBoomPoint = {}
    ret.retObjs = {}

    for _, point in ipairs(boomIns) do
        
        if self.pMap:isGap(point) == false then --//不是空隙
            
            local saveObj = xs.newMapCellObj()
            saveObj:copyFrom(self.pMap:getObj(point))

            table.insert(ret.retBoomPoint, point)
            table.insert(ret.retObjs, saveObj)
            
            --//移除爆炸点
            self.pMap:removeGap(point) 
            
            --//爆炸点是最后一个地板 则重新开始
            if(point.row == 1) then
                
                ret.isOver = true 
            end
            
        end
    end

    return ret
end

function BoomSystem:boom(from, pBomb)
    local ret = self:boom_(from, pBomb) 
    
    if ret.isOver == true then --//重新开始

    	print("Start New")
        self.pMap:reset() 
    end

    return ret
end

--/*计算爆炸源点*/
-- function BoomSystem:calcBoomPoint(BoomFromDirect direct, unsigned int num)
function BoomSystem:calcBoomPoint( direct,  num)

    --//目前只支持北方
    if (direct ~= xs.BoomFromDirect_North or num > self.pMap:getColumns()) then
        return XSTPointNull 
    end
    
    local bFind = false 
    local findPot = xs.newXSTPoint(num, 0)
    
    for row= 1, self.pMap:getRows() do
        
        findPot.row = self.pMap:getRows() - row + 1
        
        if self.pMap:isGap(findPot) == false then
        
            bFind = true 
            break 
        end
    end
    
    if (bFind) then 
    	return findPot  
    end
    
    return XSTPointNull 
end

----/*reset new state and data*/
function BoomSystem:reset()
    self.pMap:reset() 
end


return BoomSystem