-----------------------------------------------------------
-- @@ScriptName: Hero.lua
-- @@Author: popipo.yr<popipo@foxmail.com>
-- @@Create Date: 2017-5-17 13:51:22
-- @@Modify Date: 2017-5-25 15:09:52
-- @@Function:
-----------------------------------------------------------

xs = xs or {}

xs.XSTOOType_NULL = 0   --//空隙
xs.XSTOOType_Coins = 1
xs.XSTOOType_X2 = 2
xs.XSTOOType_X3 = 3
xs.XSTOOType_X4 = 4
xs.XSTOOType_X5 = 5
xs.XSTOOType_Nothing =7  --//只是泥土
xs.XSTOOType_Floor = 8 --//地板就结束

xs.XSTOOType_Count = 8

local  XSTPoint = class("XSTPoint")

xs.newXSTPoint = function (column, row )
	return XSTPoint.new(column, row)
end

function XSTPoint:ctor(column, row)
	self.column = column or 0
    self.row = row or 0
end

function XSTPoint:equalTo( other )
	return (self.column == other.column and self.row == other.row)
end

function XSTPoint:unequalTp( other )
	return (column ~= other.column or row ~= other.row)
end

----/*物件*/
local MapCellObj = class("MapCellObj")

function MapCellObj:ctor()
	self.type = XSTOOType_NULL
    self.number = 0
end

function MapCellObj:randomType()

	local types = { xs.XSTOOType_Coins,
					xs.XSTOOType_X2,
					xs.XSTOOType_X3,
					xs.XSTOOType_X4,
					xs.XSTOOType_X5,
					xs.XSTOOType_Nothing,
					xs.XSTOOType_NULL
				   }

	self.type = types[xs.random(1, #types)]
end

function MapCellObj:copyFrom( other )
	self.type = other.type;
    self.number = other.number;
end

xs.newMapCellObj = function ()
	return MapCellObj.new()
end


---炸彈的方向

xs.BoomFromDirect_West = 1 --//xi
xs.BoomFromDirect_EAST = 2 --//dong
xs.BoomFromDirect_South = 3 --//nan
xs.BoomFromDirect_North = 4  --//bei
xs.BoomFromDirect_Default = xs.BoomFromDirect_North

local BoomFrom = class("BoomFrom")

function BoomFrom:ctor( ... )
	self.direct = xs.BoomFromDirect_Default
    self.column = 0
    self.row = 0
end

function BoomFrom:copyFrom( other )
	self.direct = other.direct;
    self.column = other.column;
    self.row = other.row;
end

xs.newBoomFrom = function ( ... )
	return BoomFrom.new(...)
end


return XSTPoint, MapCellObj