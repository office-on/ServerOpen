-----------------------------------------------------------
-- @@ScriptName: BoomGameScene.lua
-- @@Author: popipo.yr<popipo@foxmail.com>
-- @@Create Date: 2014-06-20 14:59:32
-- @@Modify Date: 2015-04-16 17:03:48
-- @@Function:
-----------------------------------------------------------

require("app.UI.Game.Game")
require("app.Data.XSDataEngine.Plugin.XSDataEnginePluginWild")
require("app.Data.XSDataEngine.Plugin.XSDataEnginePluginBonus")
require("app.Data.XSDataEngine.Plugin.XSDataEnginePluginScatter")
require("app.Data.XSDataEngine.Plugin.BoosterPlugin")

require("Game_Boom")
require("Boom.BoomSystem")

local BoomGameScene = class("BoomGameScene", function (params)
    return display.newScene("BoomGameScene")
end)

function BoomGameScene:ctor(params)

    self.params = params

    cc.SpriteFrameCache:getInstance():removeSpriteFrames()

    local levelName = params.miniLevelNum

    local packageNumber = params.packageNum

    --记录添加前的路径以便后面恢复
    self._oldSeachPaths = {}
    for _, path  in ipairs(cc.FileUtils:getInstance():getSearchPaths()) do
        table.insert(self._oldSeachPaths, path)
    end

    local diff = "hd"
    diff = "1140"
    local diffPath, levelPath, levelResPath,boomRes,topRes
    if device.platform == "windows" then
        --独立项目使用绝对路径
        -- diffPath     = "res\\level\\" .. levelName .. "\\diff\\" .. diff .. "\\"
        -- levelPath    = "res\\level-d\\" .. levelName .. "\\"
        -- levelResPath = "res\\level\\" .. levelName .. "\\"
        diffPath     = "E:/Documents/Moving/Restart-Qquick-3.6/res/unpack/".. packageNumber .."/level\\" .. levelName .. "\\diff\\" .. diff .. "\\"
        levelPath    = "E:/Documents/Moving/Restart-Qquick-3.6/res/unpack/".. packageNumber .."/level-d\\" .. levelName .. "\\"
        levelResPath = "E:/Documents/Moving/Restart-Qquick-3.6/res/unpack/".. packageNumber .."/level\\" .. levelName .. "\\"
        boomRes = "E:/Documents/Moving/Restart-Qquick-3.6/res/unpack/".. packageNumber .."/level\\" .. levelName .. "\\bomb\\"
        topRes = "E:/Documents/Moving/Restart-Qquick-3.6/res/unpack/".. packageNumber .."/res/"
    else
        diffPath     = "res/unpack/".. packageNumber .."/level/" .. levelName .. "/diff/" .. diff .. "/"
        levelPath    = "res/unpack/".. packageNumber .."/level-d/" .. levelName .. "/"
        levelResPath = "res/unpack/".. packageNumber .."/level/" .. levelName .. "/"
        boomRes = "res/unpack/".. packageNumber .."/level/" .. levelName .. "/bomb/"
        topRes =   "res/unpack/".. packageNumber .."/res/"
    end

    self.levelName = levelName
    self.levelPath = levelPath

    local addSeachPaths = {diffPath,levelPath,levelResPath, boomRes, topRes}
    local fu = cc.FileUtils:getInstance()

    for _,path in ipairs(addSeachPaths) do
        fu:addSearchPath(path)
        table.insert(xs.curSearchPaths, path) 
    end


     --//设置
    local pathLine = fu:fullPathForFilename("LineInfo.json")
    local pathPatn = fu:fullPathForFilename("PatnInfo.json")

    local aRule = xs.newRule(pathPatn,pathLine)


    local btnpath      = fu:fullPathForFilename(levelPath .. "BtnInfo.json")
    local linepath     = fu:fullPathForFilename(levelPath .. "LineRGB.json")
    local wheelpath    = fu:fullPathForFilename(diffPath .. "WheelEtc.json")
    local spinInfoPath = fu:fullPathForFilename(levelPath .. "OddsInfo.json")

    local btnInfo  = xs.newBtnInfoData(btnpath)
    local line     = xs.newLineColorData(linepath)
    local wheel    = xs.newWheelRectData(wheelpath)
    local spinInfo = xs.shareSpinInfo(levelName, spinInfoPath) 


    local player   = xs.sharePlayer()
    local playChip = xs.newPlayChip(aRule:countOfLine(),player:maxBet())
    local maxChip  = xs.newPlayChip(aRule:countOfLine(),player:maxBet())

    

    --player.coins = 16

    local boomMap = xs.newBoomMap()
    local boomSystem = xs.newBoomSystem(boomMap)
    boomSystem:reset()

    -- self.boomMap:show()
    local boomPlugin = xs.newBoomPlugin(boomSystem, boomMap)


    local plugins = {xs.newPluginWild(),xs.newPluginBonus(),xs.newPluginScatter(), xs.newPluginBooster(), boomPlugin}

    local viewEtc = xs.newViewETC(aRule,btnInfo,line,wheel)

    local engine =  xs.newDataEngine(aRule, player.coins, playChip, maxChip, plugins, spinInfo)
   
    
    ----------------------------
    local  game =  xs.newGame_Boom(engine, viewEtc, self.params)

    ccb["Game"] = game


    ---/// ccb编辑为竖屏的,但是工程是横屏的,创建的layer都是横屏的尺寸 这里需要手动重设为竖屏尺寸
    local  proxy = cc.CCBProxy:create()
    local  node  = CCBReaderLoad(cc.FileUtils:getInstance():fullPathForFilename(levelResPath .. "Game.ccbi"), proxy)

    local size = node:getContentSize()
    node:setContentSize(cc.size(size.height, size.width))  

    node:setAnchorPoint(0.5, 0.5)
    node:setPosition(cc.p(display.cx , display.cy))
    node:ignoreAnchorPointForPosition(false)
    node:rotateTo(1.0, 90)
     
    game:setup(node)
    game:setRemoveCall( handler(self, BoomGameScene.clearAll) )

    self:addChild(node)


end

function BoomGameScene:clearAll( ... )
    --恢复以前的搜索路径
    local fu = cc.FileUtils:getInstance()
    fu:clearSearchPaths() 
    xs.curSearchPaths = {}   

    for _, path in ipairs(self._oldSeachPaths) do
        fu:addSearchPath(path)
        table.insert(xs.curSearchPaths,path)
    end

    package.loaded['.FingerGameScene'] = nil

    cc.SpriteFrameCache:getInstance():removeSpriteFrames()
end

function BoomGameScene:onExit()
    AudioEngine.stopMusic()
end

function BoomGameScene:onEnter()
    AudioEngine.playMusic("bg.mp3", true)
end


return BoomGameScene
