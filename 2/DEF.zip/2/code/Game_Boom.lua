-----------------------------------------------------------
-- @@ScriptName: Game_Boom.lua
-- @@Author: popipo.yr<popipo@foxmail.com>
-- @@Create Date: 2014-06-20 14:59:05
-- @@Modify Date: 2015-04-15 15:25:23
-- @@Function:
-----------------------------------------------------------

require("app.UnitTool.EventPool")

require("GameMenu_Boom")

require("Boom.BoomLayer")
require("Boom.BoomPlugin")

local Game_Boom = class("Game_Boom", require("app.UI.Game.Game"))

function Game_Boom:ctor(engine, aETC, params)

    cc.SpriteFrameCache:getInstance():removeSpriteFrames()

    local player = xs.sharePlayer()
    self._menu = xs.newGameMenu_Boom(player.coins, player:expPercent(), player.level, "Menu_Boom/Menu.ccbi")
    self._menu:setCallbackObj(self)

    local curRule =  engine:curRule()
    
    ----///竖屏需要重新设置大小,影响画线
    self._btnAndLineLayer = xs.newBtnAndLineLayer(aETC, cc.size(display.height, display.width), true)

    self._patnLayer = xs.newPatnLayer(curRule:canUsePatns(), curRule:countOfRow()
        ,curRule:countOfColumn(), aETC:getWheelRect())


    Game_Boom.super:ctor(engine, aETC)

    self.aETC =  aETC
    self.engine = engine
    self.params = params

    self._putBoomLayer = nil  --//放炸弹

    self.spinBoosterPosition = cc.p(85, 115)
end

function Game_Boom:backClick( )

    local params = {}
    params.packageNum = self.params.packageNum

    if self.removeCb then
        self.removeCb()
    end

     -- xs.enterScene("MonsterGameScene", {levelNum = 1} ,"")
     xs.enterScene("GameScene", params, "")
     AudioEngine.playEffect("Sound/btn.wav")
end

function Game_Boom:helpClick( )
    local helper =  xs.newGameHelper()
    self._layer:addChild(helper)
    AudioEngine.playEffect("Sound/btn.wav")
end

function Game_Boom:setRemoveCall(cb)
    self.removeCb = cb
end

function Game_Boom:addAnimalStateMachine()  
    self.animalSM = {}  --动画状态机
    cc.GameObject.extend(self.animalSM):addComponent("components.behavior.StateMachine"):exportMethods() 
  
    self.animalSM:setupState({  
        initial = "none",  
  
  --[[
一局已经结束 开始显示结果
数据显示  
    飞金币
    bigwin提示   有升级提示的情况下 bigwin 将不显示
     升级提示
     线动画  (包含一次所有的) ————> 如果有小游戏,或则免费,就跳过中间的根线条 
             小游戏(如果有) --> 免费转动(如果有) 

one-by-one  获奖的线条显示(如果有,一次所有的) -> 小游戏(如果有) --> 免费转动(如果有)  
--]]

        events = {  
            {name = "showBigWin", from = {"none"}, to = "bigWinStart"},
            {name = "finishBigWin", from = {"bigWinStart"}, to = "bigWinEnd"},
            {name = "drawAllLine", from = {"bigWinEnd"}, to = "allLineStart"},  
            {name = "finishAllLine", from = {"allLineStart"}, to = "allLineEnd"},  
            {name = "refreshBoom", from = {"allLineEnd"}, to = "BoomStart"},  
            {name = "finishBoom", from = {"BoomStart"}, to = "BoomEnd"},
            {name = "showMiniGame", from = {"BoomEnd"}, to = "miniGameStart"},  
            {name = "finishShowMiniGame", from = {"miniGameStart"}, to = "miniGameEnd"},  
            {name = "showFree", from = {"miniGameEnd"}, to = "showFreeStart"},  
            {name = "finishShowFree", from = {"showFreeStart"}, to = "showFreeEnd"}, 
            {name = "showFreeResult", from = {"showFreeEnd"}, to = "showFreeResultStart"},  
            {name = "finishShowFreeResult", from = {"showFreeResultStart"}, to = "showFreeResultEnd"}, 
            {name = "showLevelUp", from = {"showFreeResultEnd"}, to = "showLevelUpStart"},  
            {name = "finishShowLevelUp", from = {"showLevelUpStart"}, to = "showLevelUpEnd"}, 
            {name = "finish", from = {"showLevelUpEnd"}, to = "none"}, 
        },  

  
        callbacks = {  
                
            onenterbigWinStart = function ()  
                self:showAnimalBigWin(true)
            end, 

            onenterallLineStart = function ()  
                self:showAnimalLine(true)
            end, 

            onenterminiGameStart = function ()  
                self:showAnimalMiniGame()
            end,  
  
            onentershowFreeStart = function ()  
                self:showAnimalFree()
            end, 

            onentershowFreeResultStart = function ()  
                self:showFreeResult(true)
            end,  

            onentershowLevelUpStart = function ()  
                self:showLevelUp(true)
            end,  

            onenternone = function ()  
                self:showAnimalLineOneByOne() 
                self:animalEnd()
            end, 

            onenterBoomStart = function ()  
                self:boomrefresh()
            end, 
        },  
    })  
end  


function Game_Boom:loopAnimalEvent( ... )
    if self.animalSM:canDoEvent("showBigWin") then
        self.animalSM:doEvent("showBigWin")
    elseif self.animalSM:canDoEvent("drawAllLine") then
        self:startBoom() 
        self.animalSM:doEvent("drawAllLine")
    elseif self.animalSM:canDoEvent("refreshBoom") then
        self.animalSM:doEvent("refreshBoom")
    elseif self.animalSM:canDoEvent("showMiniGame") then
        self.animalSM:doEvent("showMiniGame")
    elseif self.animalSM:canDoEvent("showFree") then
        self.animalSM:doEvent("showFree")
    elseif self.animalSM:canDoEvent("showFreeResult") then
        self.animalSM:doEvent("showFreeResult")
    elseif self.animalSM:canDoEvent("showLevelUp") then
        self.animalSM:doEvent("showLevelUp")
    elseif self.animalSM:canDoEvent("finish") then
        self.animalSM:doEvent("finish")
    end
end

function Game_Boom:setup()

    self._specialFrameCount = 29
    self._specialFrameInterval =  0.07
    self._needCover = true

    -- self._putPatnLayer:setVisible(false)
    
    self._putPatnLayer:addChild(self._patnLayer)
    self._putLineBtnLayer:addChild(self._btnAndLineLayer)

        -----////竖屏 需要改变尺寸
    local menuSize = self._menu:getContentSize()
    local visibleSize = cc.Director:getInstance():getVisibleSize()
    local p = cc.p(visibleSize.height * 0.5, visibleSize.width - menuSize.height * 0.5)
    self._menu:align(display.CENTER, p.x, p.y)
              :addTo(self._layer)


    Game_Boom.super:configNodeContainer( self )
    Game_Boom.super:setup()

    local boomPlugin = self.engine:pluginForKey(XSDEPluginBoom_K)

    -- self.boomMap = xs.newBoomMap()
    -- self.boomSystem = xs.newBoomSystem(self.boomMap)
    -- self.boomSystem:reset()

    boomPlugin.boomMap:show()


    local rect = {}
    rect.x = 20
    rect.y = 235
    rect.width = 600
    rect.height = 335

    self.m_Bombly = xs.newBoomLayer(boomPlugin.boomMap, boomPlugin.boomSystem, self)
    self.m_Bombly:initConfig(rect);
    self._putBoomLayer:addChild(self.m_Bombly);
end



-------------------
--//改变label显示值
function Game_Boom:changeLabelValue()
    
    xs.LabelAutoScale(self._lineLabel, string.format("%d",self._engine:curChip().line), 4.0, 1.0)
    xs.LabelAutoScale(self._lastWinLabel, string.format("%.0f",self._result.winCoins), 15.0, 1.0)
    xs.LabelAutoScale(self._betLabel, string.format("%.0f",self._engine:curChip().bet), 5.0, 1.0)
    xs.LabelAutoScale(self._totalBetLabel, string.format("%.0f",self._engine:curChip():value()),11.0, 1.0)
end


---/*通知掉炸弹*/
function Game_Boom:startBoom()
    

    local boomPlugin = self.engine:pluginForKey(XSDEPluginBoom_K)
    self.ret = boomPlugin:getBoomResult() 

    if self.ret ~= nil then

        local scaleX, scaleY = 1, 1

        local indexOfWheel = self.ret.rcpoint.c;
        local rowInWheel = self.ret.rcpoint.r;
        if (self.engine:curRule():countOfColumn() >= indexOfWheel) then
            local wheel = self._patnLayer:getWheel(indexOfWheel);
            wheel:changePatnVisible(rowInWheel, false);
            scaleX, scaleY = wheel:getScaleXAndY(rowInWheel)
        end

        local point = self.aETC:coverXSPointToPoint(self.ret.rcpoint);    
        self.m_Bombly:onCallback(point, self.ret, scaleX, scaleY);
    end

end


function Game_Boom:boosterItemClick()
    local boosterLayer =  xs.newBoosterLayer()

    boosterLayer:setAnchorPoint(0.5, 0.5)
    boosterLayer:setPosition(cc.p(display.cy , display.cx))
    boosterLayer:setRotation(-90)

    self._layer:addChild(boosterLayer)
    AudioEngine.playEffect("Sound/btn.wav")
end


function Game_Boom:boomrefresh()

    if self.ret == nil or self.ret.isOver == false then
        self.animalSM:doEvent("finishBoom")
        self:loopAnimalEvent()
    end

end 

function Game_Boom:freshCB( )
        
    self.animalSM:doEvent("finishBoom")
    self:loopAnimalEvent()

end


function Game_Boom:maxSpinItemClick()
    
    local keeper = xs.newGameKeeper( cc.size(display.height, display.width) )
    keeper:setKeepBackShow(false)
    keeper:addKeeperEventListener(handler(self, self.keeperChoose))

    self._layer:addChild(keeper)
    AudioEngine.playEffect("Sound/btn.wav")
end


xs = xs or {}
function xs.newGame_Boom(...)
    return Game_Boom.new(...)
end

return Game_Boom
