-----------------------------------------------------------
-- @@ScriptName: GameScene.lua
-- @@Author: popipo.yr<popipo@foxmail.com>
-- @@Create Date: 2014-06-20 14:59:32
-- @@Modify Date: 2015-04-16 17:03:48
-- @@Function:
-----------------------------------------------------------

require("app.UI.Menu.GameMenu")
require("app.Data.GameData.XSPackageInfo")
require("app.Data.GameData.XSPlayer")


local GameScene = class("GameScene", function (params)
    return display.newScene("GameScene")
end)



function GameScene:ctor(params)

    self.params = params

    local packageNumber = params.packageNum

    local topRes

    if device.platform == "windows" then
        --独立项目使用绝对路径
        topRes = "res/unpack/".. packageNumber .."/res/"
        -- topRes = "E:/Documents/Moving/Restart-Qquick-3.6/res/unpack/".. packageNumber .."/res/"
    else
        topRes = "res/unpack/".. packageNumber .."/res/"
    end

    --记录添加前的路径以便后面恢复
    self._oldSeachPaths = {}
    for _, path  in ipairs(cc.FileUtils:getInstance():getSearchPaths()) do
        table.insert(self._oldSeachPaths, path)
    end

    local fu = cc.FileUtils:getInstance()
    fu:addSearchPath(topRes)


    ccb["MiniLevelChoose"] = self   
    local  proxy = cc.CCBProxy:create()
    local  node  = CCBReaderLoad(cc.FileUtils:getInstance():fullPathForFilename("MiniLevelChoose/MiniLevelChoose.ccbi"), proxy)

    self:addChild(node)


    local player = xs.sharePlayer()
    local menu = xs.newGameMenu(player.coins, player:expPercent(), player.level, "Menu/Menu.ccbi")
    menu:setCallbackObj(self)

    local menuSize = menu:getContentSize()
    local visibleSize = cc.Director:getInstance():getVisibleSize()
    local p = cc.p(visibleSize.width * 0.5, visibleSize.height - menuSize.height * 0.5)
    menu:align(display.CENTER, p.x, p.y)
              :addTo(self)

    self:refreshBtnStatus()
end

function GameScene:backClick( )

    self:clearAll()
    
    xs.outBigLevelClearLuaPath(self.params.packageNum)
    App:enterScene("HomeScene")
end

function GameScene:onExit()
    AudioEngine.stopMusic()
end

function GameScene:onEnter()
    AudioEngine.playMusic("Sound/home.mp3", true)
end


  function GameScene:clearAll( ... )
      -- body
          --恢复以前的搜索路径
    local fu = cc.FileUtils:getInstance()
    fu:clearSearchPaths() 
    xs.curSearchPaths = {}   

    for _,path in ipairs(self._oldSeachPaths) do
        fu:addSearchPath(path)
        table.insert(xs.curSearchPaths,path)
    end

    package.loaded['GameScene'] = nil

    cc.SpriteFrameCache:getInstance():removeSpriteFrames()
  end


 function GameScene:chooseLevel(tag, sender)

    self:clearAll()

    local miniLevelNum = tag - 100
    self.params.miniLevelNum = miniLevelNum

    xs.enterScene("BoomGameScene", self.params ,"")
    AudioEngine.playEffect("Sound/levelChoose.wav")
 end

 function GameScene:refreshBtnStatus()

    if self.params.packageNum ~= xs.sharePlayer().openPackage then
        --用户当前打开的包号和当前包不一致,那么肯定是全开的,直接返回
        return    
    end 

    local openedMini = xs.sharePlayer().openMiniLevel
    local miniTotal  = 5

    for _, menuItem in ipairs(self.menu:getChildren()) do
        
        local tag = menuItem:getTag()
        local miniLevelNum = tag - 100 

        ---大于,改为不可点击状态
        if miniLevelNum > openedMini then
            menuItem:setEnabled(false)
        end 

    end
     
 end


return GameScene
